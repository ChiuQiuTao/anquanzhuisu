<template>
    <div class="password">
        <div class="item">
            <div class="item-left">
                登录密码
            </div>
            <div class='item-right'>
                <i-input size="small" placeholder="" style="width: 166px;"></i-input>
            </div>
        </div>

        <div class="item">
            <div class="item-left">
                新密码
            </div>
            <div class='item-right'>
                <i-input size="small" placeholder="" style="width: 166px;"></i-input>
            </div>
        </div>

        <div class="item">
            <div class="item-left">
                确定密码
            </div>
            <div class='item-right'>
                <i-input size="small" placeholder="" style="width: 166px;"></i-input>
            </div>
        </div>

        <div class="item">
            <i-button type="primary" shape="circle" class="btn-c" size="small">确定修改</i-button>
        </div>
    </div>
</template>

<script>
import './index.less'
export default {

}
</script>

<style>

</style>
