<template>
  <div>
    <p>gis</p>
    <p style="height:800px;">sd放松放松fsd</p>
    <Icon :size="18" type="arrow-resize"></Icon>
    <Icon :size="18" type="md-arrow-dropdown"></Icon>
    <Icon :size="18" type="chatboxes"></Icon>
  </div>
</template>
<script>
export default {
  name: "About-Us"
};
</script>
