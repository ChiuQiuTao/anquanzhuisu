<template>
    <Row>
        <i-col span="24" class="search-company">
            <section>
                <section class="type-title">
                    企业名称
                </section>
                <section class="type-select">
                     <i-input :value.sync="value" placeholder="" style="width:160px;" class="type-select-c"></i-input>
                </section>
            </section>

            <section>
                <section class="type-btn">
                    <i-button type="primary" shape="circle" class="type-btn-c" size="small">查询</i-button>
                    <i-button type="primary" shape="circle" class="type-btn-c" size="small">重置</i-button>
                </section>
            </section>
        </i-col>
    </Row>
</template>

<script>

import './index.less'

export default {
  // data(){
  //     return
  // }
}
</script>
